# QA Results — v98.63.9.33

## Local verification
- `node --check assets/js/app.js`: PASS
- `node --check service-worker.js`: PASS
- `node --check scripts/prepare-android-web.mjs`: PASS
- `node --check scripts/patch-android-native.mjs`: PASS
- `npm run build:web`: PASS; `www/` regenerated from authoritative root source.
- `npm run test:release`: PASS — 55 tests, 0 failures.
- Android workflow YAML parse: PASS.
- `.github/workflows/main.yml` and `Android-Workflow-v98.63.9.33.yml`: byte-identical.
- Root source and generated `www/` app.js, app.css, index.html, manifest and service worker: synchronized by build/test.
- ZIP integrity: checked after packaging.

## UI correction
- Removed four embedded legacy numeric keypads from currency, unit, discount and percent tools.
- Removed the old keypad modal overlay, title and detached value-preview markup.
- Kept one shared docked keypad for numeric tools; first visible field is activated on entry.
- Unit category selection activates the shared keypad after the amount field becomes visible.
- Equals/Calculate retains the keypad and scrolls the result into the unobstructed area above it.
- Added history-token protection so a delayed Android Back event from a previous tool cannot close the next tool's keypad.
- Main calculator keypad and specialized hexadecimal keypad remain independent.

## Android build status
The workflow now provisions Android SDK API 35, Build Tools 35.0.0 and platform-tools, and checks `adb`/`aapt` before the native build. A hosted GitHub Actions Gradle/APK run and physical-device rendering test have not yet been executed in this environment; no APK success is claimed here.
