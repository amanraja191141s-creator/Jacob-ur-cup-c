# QA Results — v98.63.9.34 Action preflight hotfix

## Confirmed issue
The release preflight workflow checked for service-worker cache suffix `v9863933`, but the v98.63.9.34 service worker uses `v9863934`. The workflow therefore contained a deterministic false-negative release check.

## Fix
- Updated `.github/workflows/main.yml` to validate `v9863934`.
- Updated the standalone `Android-Workflow-v98.63.9.34.yml` mirror identically.
- Added a regression test that reads the actual service-worker source and checks that the workflow asserts the same cache suffix.

## Local verification
- `npm run build:web`: PASS (13 required assets verified).
- `npm run test:release`: PASS (56 tests, 0 failures).
- Focused action/cache preflight tests: PASS (8 tests, 0 failures).
- Root workflow and standalone mirror: byte-identical.
- YAML parse: PASS.
- ZIP integrity: PASS.

## Limits
The dependency-install attempt in this environment timed out, so no local Capacitor/Gradle APK build is claimed. The pasted Actions excerpt contains durations but no explicit step conclusions or error text; this fix addresses the confirmed source/workflow mismatch, not an unshown independent runner failure. A fresh GitHub Actions run is still required to confirm hosted APK build and artifact upload.
