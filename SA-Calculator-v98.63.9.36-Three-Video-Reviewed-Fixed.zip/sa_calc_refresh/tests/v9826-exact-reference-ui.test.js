const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('v98.27 converter reference shell uses compact calculator header and tool-specific toolbar', () => {
  const css = read('assets/css/app.css');
  const js = read('assets/js/app.js');
  assert.match(css, /v98\.27 — EXACT 18-SCREEN REFERENCE REBUILD/);
  assert.match(css, /body\.tool-screen-active header\.app-header \{ display:none !important/);
  assert.match(js, /className = 'reference-screen-toolbar'/);
  assert.match(css, /\.reference-screen-toolbar/);
  assert.match(css, /\.bottom-navigation/);
});

test('all reference destinations retain their IDs and reference palette', () => {
  const html = read('index.html'); const css = read('assets/css/app.css');
  const ids = ['calc','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','settings'];
  for (const id of ids) assert.ok(html.includes(`id="screen-${id}"`), `missing screen ${id}`);
  for (const color of ['#061326','#0a1b33','#0788ff','#55ed9b']) assert.ok(css.includes(color), `missing ${color}`);
});

test('currency selector includes country flag and localized name without replacing original select IDs', () => {
  const html = read('index.html'); const js = read('assets/js/app.js');
  for (const id of ['cur-from','cur-to','cur-from-flag','cur-to-flag','cur-from-name','cur-to-name']) assert.ok(html.includes(`id="${id}"`));
  assert.match(js, /function currencyFlagForCode\(currencyCode\)/);
  assert.match(js, /const CURRENCY_FLAG_REGIONS = \{/);
  assert.match(js, /currency-picker-flag/);
  assert.match(js, /sumaire-picker-option-flag/);
  assert.match(js, /setElementText\('cur-from-flag', currencyFlag\(fromCode\)\)/);
});

test('version and workflow identities match and both workflow files are identical', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const sw = read('service-worker.js'); const html = read('index.html');
  const workflow = read('.github/workflows/main.yml'); const alias = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  assert.equal(manifest.version, pkg.version);
  assert.ok(html.includes(pkg.version));
  assert.ok(read('assets/js/app.js').includes(`const APP_VERSION = '${pkg.version}'`));
  assert.match(sw, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(workflow, /versionCode='1098065'/);
  assert.equal(workflow, alias);
});
