const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('v98.33 loads the unified premium system after compatibility styles', () => {
  const html = read('index.html');
  assert.match(html,/assets\/css\/app\.css/);
  assert.match(html,/assets\/css\/app\.css/);
  assert.doesNotMatch(html,/rebuild-v98\./);
  assert.match(read('scripts/prepare-android-web.mjs'),/assets\/css\/app\.css/);
  assert.match(read('service-worker.js'),/\.\/assets\/css\/app\.css/);
});

test('v98.33 uses one shared on-demand numeric keypad for tool fields', () => {
  const css = read('assets/css/app.css');
  const html = read('index.html');
  assert.match(css, /#screen-viewport>\.screen:not\(#screen-calc\)>\.dock-keypad:not\(\.hex-dock-keypad\)\{display:none!important\}/);
  assert.match(css, /#popup-keypad-sheet\.active/);
  assert.match(html, /id="popup-keypad-sheet"/);
  assert.match(html, /id="screen-calc"[\s\S]*?class="main-keypad"/);
});

test('v98.33 hexadecimal keypad is on-demand and has an explicit Done action', () => {
  const html = read('index.html'), js = read('assets/js/app.js'), css = read('assets/css/app.css');
  assert.match(html, /id="hex-keyboard-sheet" aria-hidden="true"/);
  assert.match(html, /id="hex-keyboard-done"/);
  assert.match(js, /function openHexKeyboard\(\)/);
  assert.match(js, /function closeHexKeyboard\(\)/);
  assert.match(js, /openHexKeyboard\(\);/);
  assert.match(css, /\.hex-keyboard-sheet\.active\{display:flex!important\}/);
});

test('v98.33 premium visual system covers all registered screens and responsive modes', () => {
  const css = read('assets/css/app.css');
  for (const selector of ['#screen-calc', '#screen-currencies', '#screen-units', '#screen-discount', '#screen-percent', '#screen-salestax', '#screen-bodymetrics', '#screen-date', '#screen-fuelcost', '#screen-fuelefficiency', '#screen-gradeavg', '#screen-hex', '#screen-loan', '#screen-savings', '#screen-tip', '#screen-unitprice', '#screen-worldtime', '#screen-settings']) assert.ok(css.includes(selector), `Missing styling coverage: ${selector}`);
  assert.match(css, /orientation:landscape/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(css, /data-theme="light"/);
});

test('v98.33 release identity, service worker and Android workflows are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const html = read('index.html'), js = read('assets/js/app.js'), sw = read('service-worker.js');
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  assert.equal(manifest.version, pkg.version);
  assert.match(html, /1\.98\.65-v98\.63\.9\.17/);
  assert.match(js, /const APP_VERSION = '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(sw, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
  const workflows = ['.github/workflows/main.yml','.github/workflows/main.yml','.github/workflows/main.yml','.github/workflows/main.yml'].map(read);
  assert.ok(workflows.every(w => w === workflows[0]));
  assert.match(workflows[0], /versionCode='1098065'/);
  assert.match(workflows[0],/assets\/css\/app\.css/);
});
