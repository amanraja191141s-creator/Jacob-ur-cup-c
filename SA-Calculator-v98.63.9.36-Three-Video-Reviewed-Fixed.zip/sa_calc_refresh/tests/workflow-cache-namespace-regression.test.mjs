import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source = fs.readFileSync('service-worker.js', 'utf8');
const generated = fs.readFileSync('www/service-worker.js', 'utf8');
const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');
const cache = source.match(/const CACHE\s*=\s*['"]([^'"]+)['"]/)?.[1];
const requiredFilesSection = workflow.match(/required_files=\([\s\S]*?\)/)?.[0] || '';
test('root and generated service worker cache namespaces match', () => {
  assert.ok(cache, 'source CACHE constant must exist');
  assert.ok(generated.includes(cache), 'www cache namespace should match source');
});
test('workflow checks selected source cache dynamically, not stale v29 marker', () => {
  assert.match(workflow, /const cacheMatch = sw\.match\(/);
  assert.match(workflow, /www\/service-worker\.js/);
  assert.match(workflow, /Generated service-worker cache namespace is stale/);
  assert.doesNotMatch(workflow, /v9863929-scientific-key-size-video-reference/);
  assert.ok(requiredFilesSection.includes('tests/v98634-marked-screenshot-cleanup.test.mjs'), 'workflow must reference the existing marked screenshot cleanup test');
  assert.ok(fs.existsSync('tests/v98634-marked-screenshot-cleanup.test.mjs'), 'referenced test file must exist');
});
