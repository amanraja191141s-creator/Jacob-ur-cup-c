import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
test('v98.41 release identity and final stylesheet are wired into the actual app', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  const html = read('index.html');
  assert.match(html, /href="assets\/css\/app\.css"/);
  assert.doesNotMatch(html, /sa-css-source-layers|rebuild-v98\./);
  assert.match(html, /class="calc-display" id="calc-display-box"|id="calc-display-box" class="calc-display"/);
  assert.match(read('assets/js/app.js'), /APP_VERSION = '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(read('manifest.webmanifest'), /1\.98\.65-v98\.63\.9\.17/);
  assert.match(read('service-worker.js'), /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});
test('closed drawer and its focused search control cannot paint a clipped edge', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /#sidebar-drawer:not\(\.active\)[\s\S]*visibility:\s*hidden\s*!important/);
  assert.match(css, /#sidebar-drawer:not\(\.active\)[\s\S]*pointer-events:\s*none\s*!important/);
  assert.match(css, /#sidebar-drawer:not\(\.active\) \.drawer-search-wrap:focus-within[\s\S]*box-shadow:\s*none\s*!important/);
});
test('skip link has no touch outline but remains keyboard accessible', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /\.skip-to-workspace[\s\S]*clip-path:\s*inset\(50%\)/);
  assert.match(css, /body\.keyboard-modality \.skip-to-workspace:focus-visible[\s\S]*clip-path:\s*none/);
});
test('display boundary fix targets the real classes in index.html', () => {
  const html = read('index.html'), css = read('assets/css/app.css');
  for (const cls of ['calc-display','calc-expression-row','calc-preview-row','calc-expression-text','calc-preview-val']) assert.ok(html.includes(`class="${cls}"`) || html.includes(`class="${cls} `), `missing ${cls}`);
  assert.match(css, /#screen-calc > \.calc-display[\s\S]*border:\s*0\s*!important/);
  assert.match(css, /#screen-calc > \.calc-display::before[\s\S]*display:\s*none\s*!important/);
  assert.match(css, /\.calc-expression-row,[\s\S]*\.calc-preview-row,[\s\S]*\.calc-expression-text,[\s\S]*\.calc-preview-val[\s\S]*border:\s*0/);
});
test('actual bottom navigation id is bounded and keypad consumes remaining space', () => {
  const html=read('index.html'), css=read('assets/css/app.css');
  assert.match(html, /<nav class="bottom-navigation" id="bottom-navigation"/);
  assert.match(css, /#app-container > #bottom-navigation[\s\S]*flex:\s*0 0 68px/);
  assert.match(css, /#app-container > #bottom-navigation \.bottom-nav-item[\s\S]*height:\s*58px/);
  assert.match(css, /#screen-calc \.main-keypad[\s\S]*flex:\s*1 1 0/);
});
test('converter icon-only keys retain accessible labels and real actions', () => {
  const html=read('index.html'), css=read('assets/css/app.css');
  for (const action of ['DEL','NEXT','CLR','DONE']) assert.match(html, new RegExp(`data-num="${action}"[^>]*aria-label="`));
  assert.match(css, /data-num="DEL"\]\:\:after[\s\S]*content:\s*"⌫"/);
  assert.match(css, /data-num="NEXT"\]\:\:after[\s\S]*content:\s*"⇄"/);
});
test('Android bundle builder and service worker require v98.41 stylesheet', () => {
  assert.match(read('scripts/prepare-android-web.mjs'), /assets\/css\/app\.css/);
  assert.match(read('service-worker.js'), /assets\/css\/app\.css/);
});
