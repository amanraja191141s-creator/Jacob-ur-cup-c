import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const root = new URL('../', import.meta.url);
const html = readFileSync(new URL('index.html', root), 'utf8');
const js = readFileSync(new URL('assets/js/app.js', root), 'utf8');
const css = readFileSync(new URL('assets/css/app.css', root), 'utf8');
const pkg = JSON.parse(readFileSync(new URL('package.json', root), 'utf8'));

test('release identity and Android code are incremented together', () => {
  assert.equal(pkg.version, '1.98.78-v98.63.9.36');
  assert.equal(pkg.androidVersionCode, 1098084);
  assert.match(html, /1\.98\.78-v98\.63\.9\.36/);
  assert.match(js, /const APP_VERSION = '1\.98\.78-v98\.63\.9\.36'/);
});
test('only one shared numeric tool keypad exists; legacy modal markup is absent', () => {
  assert.equal((html.match(/id="tool-keypad-dock"/g) || []).length, 1);
  assert.doesNotMatch(html, /popup-keypad-overlay|popup-keypad-header|popup-input-preview|popup-val-display/);
  assert.match(html, /class="main-keypad"/);
  assert.match(html, /hex-dock-keypad/);
});
test('legacy popup keypad CSS cascade is removed, not hidden by another override', () => {
  const occurrences = (css.match(/#tool-keypad-dock\s*\{[^}]*position:\s*absolute/g) || []).length;
  assert.equal(occurrences, 1, 'one authoritative app-anchored dock base rule remains');
  assert.doesNotMatch(css, /popup-keypad|popup-input-preview|popup-preview|popup-close-btn/);
});
test('keypad panel and grid fill the complete width and all key cells stretch', () => {
  assert.match(css, /#app-container \{ position: relative !important; \}/);
  assert.match(css, /position: absolute !important; inset: auto 0 0 0 !important/);
  assert.match(css, /width: 100% !important; min-width: 0 !important; max-width: none !important/);
  assert.match(css, /display: grid !important; flex: 1 1 auto !important; align-self: stretch !important/);
  assert.match(css, /grid-template-columns: repeat\(4,minmax\(0,1fr\)\) !important/);
  assert.match(css, /justify-items:\s*stretch !important; align-items:\s*stretch !important/);
  assert.match(css, /aspect-ratio: auto !important/);
  const dockRules = css.slice(css.lastIndexOf('v98.63.9.36 — robust full-width tool keypad'));
  assert.doesNotMatch(dockRules, /aspect-ratio:\s*1\s*\/\s*1\s*!important/);
});
test('scroll space is measured from the same keypad height token', () => {
  assert.match(css, /--tool-keypad-height: min\(42dvh, 360px\)/);
  assert.match(css, /padding-bottom:\s*calc\(var\(--tool-keypad-height\) \+ 18px/);
  assert.match(js, /const keypadTop = sheet\.getBoundingClientRect\(\)\.top/);
});
test('result cards from visible tool tabs are revealed above the actual dock', () => {
  assert.match(js, /const results = Array\.from\(screen\.querySelectorAll/);
  assert.match(js, /getBoundingClientRect\(\)\.top - 16/);
  assert.match(js, /Math\.max\(\.\.\.results\.map/);
  assert.doesNotMatch(js, /const safeBottom = window\.innerHeight/);
});
test('equals keeps the keypad open and calculates without dismissing the dock', () => {
  const branch = js.match(/if \(key === 'EQUAL'\) \{([\s\S]*?)\n  \} else if \(key === 'CLR'\)/)?.[1] || '';
  assert.match(branch, /recalculateCurrentScreen\(\)/);
  assert.match(branch, /revealToolResultsAboveKeypad\(\)/);
  assert.doesNotMatch(branch, /closePopupKeypad/);
});


test('video-matched Loan, SIP Delay Cost and Tip screens replace their legacy controls', () => {
  const loan = html.match(/id="screen-loan"[\s\S]*?<div class="screen" id="screen-salary">/)?.[0] || '';
  const sip = html.match(/id="screen-sip"[\s\S]*?<div class="screen" id="screen-tip">/)?.[0] || '';
  const tip = html.match(/id="screen-tip"[\s\S]*?<div class="screen" id="screen-unitprice">/)?.[0] || '';
  assert.match(loan, /id="loan-tenure"/);
  assert.match(loan, /name="loan-tenure-unit"/);
  assert.match(loan, /id="loan-results"/);
  assert.doesNotMatch(loan, /loan-amort|loan-grace|loan-method|loan-calculate|loan-years/);
  assert.match(sip, /SIP Delay Cost/);
  assert.match(sip, /id="sip-delay-months"/);
  assert.match(sip, /id="sip-delay-rate"/);
  assert.match(js, /Can’t Enter More Than 12 Months/);
  assert.match(tip, /id="tip-bill"/);
  assert.match(tip, /id="tip-pct"/);
  assert.match(tip, /id="tip-people"/);
  assert.doesNotMatch(tip, /data-tip-preset|tip-tax|tip-exclude-tax|tip-calculate/);
  assert.match(css, /#screen-viewport #screen-units #unit-result-val[\s\S]*?overflow-wrap:anywhere/);
  assert.match(html, /class="calc-card unit-category-state" hidden/);
  assert.doesNotMatch(html, /id="unit-convert-action"/);
  assert.doesNotMatch(js, /unit-convert-action/);
});
