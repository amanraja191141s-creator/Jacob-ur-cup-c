import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const workflow=fs.readFileSync('.github/workflows/main.yml','utf8');
const sw=fs.readFileSync('service-worker.js','utf8');

test('v98.63.9.26 tool cards enforce horizontal readable labels in a responsive 3-column grid',()=>{
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card \{[\s\S]*?flex-direction:column!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card > \.premium-tool-name \{[\s\S]*?writing-mode:horizontal-tb!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card > \.premium-tool-name \{[\s\S]*?overflow-wrap:normal!important/);
  assert.match(css,/#screen-tools\.premium-tools-screen\.active[\s\S]*?overflow-y:auto!important/);
  const groups=html.match(/class="tools-reference-section"[\s\S]*?<\/div><\/div>/g)||[];
  const ids=[...html.matchAll(/data-tool-screen="([^"]+)"/g)].map(m=>m[1]);
  assert.equal(ids.length,19); assert.equal(new Set(ids).size,19);
  for (const id of ids) assert.ok(html.includes(`id="screen-${id}"`), `missing destination screen-${id}`);
  assert.match(js,/toolsGrid\?\.addEventListener\('click'/);
  assert.equal((html.match(/class="tools-reference-section"/g)||[]).length,4);
});

test('scientific overlay is wide enough for legible 4x4 controls and larger touch targets',()=>{
  assert.match(css,/#screen-calc #screen-scientific\.scientific-drawer \{[\s\S]*?width:min\(94vw,680px\)!important/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid > button \{[\s\S]*?min-height:48px!important/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid \{[\s\S]*?repeat\(4,minmax\(0,1fr\)\)!important/);
  const grid=html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0]||'';
  assert.equal((grid.match(/<button\b/g)||[]).length,16);
  assert.match(js,/insertScientificIntoMain\(token\)/);
});

test('cache, PWA, app and Android workflow use one fresh v98.63.9.26 release identity',()=>{
  assert.equal(pkg.version,'1.98.76-v98.63.9.29');
  assert.match(html,/1\.98\.76-v98\.63\.9\.29/);
  assert.match(js,/APP_VERSION = '1\.98\.76-v98\.63\.9\.29'/);
  assert.match(sw,/v9863929-scientific-key-size-video-reference/);
  assert.match(workflow,/SA_EXPECTED_VERSION: '1\.98\.76-v98\.63\.9\.29'/);
  assert.equal(pkg.androidVersionCode,1098077);
  assert.match(workflow,/const androidVersionCode = Number\(pkg\.androidVersionCode \?\? derivedVersionCode\)/);
  assert.match(workflow,/Ambiguous exact-version source archives found/);
  assert.match(workflow,/android_version_code=\$\{androidVersionCode\}/);
  assert.match(workflow,/versionCode='\$\{\{ steps\.locate\.outputs\.android_version_code \}\}'/);
  assert.match(workflow,/v9863929-scientific-key-size-video-reference/);
});


test('scientific angle mode initializes from saved preference and exposes accessible state',()=>{
  assert.match(js,/initialAngleButton\.textContent = sci\.angle\.toUpperCase\(\)/);
  assert.match(js,/initialAngleButton\.setAttribute\('aria-pressed', String\(sci\.angle === 'rad'\)\)/);
  assert.match(js,/angleButton\.setAttribute\('aria-pressed', String\(sci\.angle === 'rad'\)\)/);
  assert.match(js,/Angle mode \$\{sci\.angle\.toUpperCase\(\)\}; toggle degrees or radians/);
});

test('scientific controls retain 48px touch targets on short screens and expose keyboard focus',()=>{
  assert.match(css,/@media\(max-height:620px\) \{[\s\S]*?scientific-function-grid > button \{ min-height:48px!important/);
  assert.match(css,/@media\(max-height:620px\) \{[\s\S]*?scientific-more-functions > button \{ min-height:48px!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card:focus-visible/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid > button:focus-visible/);
});


test('scientific keypad matches clean pink reference: text-only keys without borders or helper labels',()=>{
  const clean=css.slice(css.lastIndexOf('v98.63.9.25 — clean reference-style'));
  assert.match(clean,/#screen-calc #screen-scientific\.scientific-drawer\s*\{[\s\S]*?background:#e9518d!important/);
  assert.match(clean,/scientific-function-grid > button\s*\{[\s\S]*?border:0!important;[\s\S]*?background:transparent!important/);
  assert.match(clean,/scientific-function-grid > button\s*\{[\s\S]*?box-shadow:none!important/);
  assert.match(clean,/scientific-display,[\s\S]*?sci-angle-toggle,[\s\S]*?sci-drawer-close \{ display:none!important/);
  assert.match(clean,/#sci-more-toggle\s*\{[\s\S]*?border-radius:50%!important;[\s\S]*?background:#29262e!important/);
  assert.match(html,/id="sci-shift-toggle"/); assert.match(html,/id="sci-more-toggle"/);
  assert.match(js,/data-sci-insert/);
});


test('plus control toggles a clean expanded panel with an explicit close state',()=>{
  assert.match(js,/const expanded=panel\.hidden;panel\.hidden=!expanded;toggle\.setAttribute\('aria-expanded',String\(expanded\)\);toggle\.textContent=expanded\?'×':'＋'/);
  assert.match(js,/expanded\?'Close additional scientific functions':'More scientific functions'/);
  assert.match(js,/if \(event\.key !== 'Escape' \|\| !drawerOpen\) return;[\s\S]*?if \(more && !more\.hidden\)/);
  assert.match(js,/more\.hidden = true;[\s\S]*?moreToggle\.textContent = '＋'/);
  assert.match(js,/editor\.addEventListener\('keydown',[\s\S]*?if \(more && !more\.hidden\)[\s\S]*?event\.stopPropagation\(\); more\.hidden = true/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-more-functions:not\(\[hidden\]\)\s*\{[\s\S]*?background:#e9518d!important/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-more-functions > button\s*\{[\s\S]*?border:0!important;[\s\S]*?background:transparent!important;[\s\S]*?box-shadow:none!important/);
  assert.match(html,/id="sci-more-toggle" aria-expanded="false" aria-controls="sci-more-functions"/);
  assert.match(html,/id="sci-more-functions" hidden/);
  assert.equal((html.match(/data-sci-insert="[^"]+"/g)||[]).length >= 32, true);
});
