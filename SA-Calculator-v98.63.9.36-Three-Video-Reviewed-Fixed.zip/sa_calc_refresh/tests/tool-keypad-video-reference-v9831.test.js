'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

test('tool numeric keypad is one shared docked surface and opens on tool entry', () => {
  assert.match(html, /id="tool-keypad-dock"[^>]*aria-label="Numeric keypad"/);
  assert.doesNotMatch(html, /popup-keypad|popup-input-preview|popup-preview/);
  assert.match(css, /#tool-keypad-dock\s*\{[\s\S]*?visibility: hidden !important/);
  assert.match(css, /#tool-keypad-dock\.active[\s\S]*?pointer-events: auto !important/);
  assert.match(css, /height: var\(--tool-keypad-height\) !important/);
  assert.match(js, /if \(first\) openToolKeypad\(first\)/);
  assert.match(js, /document\.body\.classList\.add\('tool-keypad-active'\)/);
  assert.match(js, /document\.body\.classList\.remove\('tool-keypad-active'\)/);
  assert.match(js, /window\.history\.pushState\(\{ \.\.\.\(window\.history\.state \|\| \{\}\), saToolKeypad: currentKeypadHistoryToken \}/);
  assert.match(js, /pendingKeypadHistoryPopToken/);
  assert.match(js, /window\.history\.back\(\)/);
});

test('keypad layout matches the four-column reference with a two-row equals key', () => {
  for (const key of ['7','8','9','CLR','4','5','6','DEL','1','2','3','EQUAL','00','0','.']) {
    assert.match(html, new RegExp(`data-tool-key="${key}"`));
  }
  assert.match(css, /grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
  assert.match(css, /grid-template-rows:repeat\(4,minmax\(0,1fr\)\)!important/);
  assert.match(css, /grid-row: 3 \/ span 2 !important/);
  assert.doesNotMatch(html, /data-tool-key="NEXT"|data-tool-key="DONE"/);
});

test('equals calculates the active tool and keeps the docked keypad visible above results', () => {
  const equalBranch = js.slice(js.indexOf("if (key === 'EQUAL')"), js.indexOf("} else if (key === 'CLR')", js.indexOf("if (key === 'EQUAL')")));
  assert.match(equalBranch, /recalculateCurrentScreen\(\)/);
  assert.match(equalBranch, /persistPreviousInputs\(\)/);
  assert.match(equalBranch, /revealToolResultsAboveKeypad\(\)/);
  assert.doesNotMatch(equalBranch, /closeToolKeypad\(\)/);
  assert.match(js, /function revealToolResultsAboveKeypad\(\)/);
  assert.match(js, /sheet\.getBoundingClientRect\(\)\.top/);
  assert.match(js, /button\[id\$=\"-calculate\"\][\s\S]*?revealToolResultsAboveKeypad/);
});
