# Three-video micro-level review and corrective patch — v98.63.9.36

Review date: 2026-11-22
Reference inputs:
- Screenrecording_20261122_171412.mp4 (45.67 s; 720×1560)
- Screenrecording_20261122_132803.mp4 (70.09 s; 720×1560)
- Screenrecording_20261122_115940.mp4 (24.90 s; 720×1560)

## 1. Video-derived behavior

### Video 1 — Loan Calculator
Observed sequence:
- Tool launcher opens the Finance & Money section.
- Loan screen has three separately focusable fields: Loan Amount, Rate of Interest, Loan Tenure.
- A Months / Years radio selector changes tenure interpretation.
- A shared docked numeric keypad is used for number entry, clear, delete and equals.
- Validation is surfaced as short toast messages; the recording shows a minimum amount of 100 and a 40-year maximum.
- On successful calculation, the result card presents Monthly Payment, Loan Amount, Interest Amount and Total Payable.

Observed sample: principal 899, annual interest 96%, tenure 9. The screen shows different EMI values when the same 9 is interpreted as months versus years. The current source implements standard reducing-balance EMI:
`EMI = P × r × (1+r)^n / ((1+r)^n − 1)`, with `r = annualRate/1200`.
The source also validates amount >= 100, rate 0–100%, integer months, and no more than 480 months / 40 years.

### Video 2 — Unit Converter and SIP
Unit converter:
- A category grid is shown before entering the conversion workspace.
- A category opens a focused conversion screen with editable source value, From and To selectors, swap control, converted result and shared keypad.
- The recording demonstrates Volume, Voltage and Temperature.
- Temperature sample 1,999,999 °C → 3,600,030.2 °F is consistent with the standard conversion equation.
- Voltage sample 1 V → 1,000 mV is correct.
- The source uses physical conversion factors and rejects impossible temperatures below absolute zero in Kelvin.

SIP:
- Two tabs switch between SIP Calculator and SIP Delay Cost.
- Delay Cost accepts Monthly SIP Amount, Investment Period, Expected Return Rate and delay in months.
- The recording shows a 12-month maximum delay validation.
- Results in the reference include start-today value, delayed-start value, loss/cost of delay and an additional “In today’s money value” line.
- The prior source rendered only three result lines. This patch adds the fourth present-value line and documents its 6% annual inflation assumption.

Numerical reconciliation note:
For the displayed inputs 988 monthly, 8 years, 9% return and 9-month delay, the current source's standard monthly-annuity engine calculates 138,177.89 (start today), 120,623.72 (delayed) and 17,554.17 (difference). The recording displays 137,043.91, 119,824.80 and 17,219.00. The video does not expose the alternative compounding/timing assumptions that produce those exact figures, so the patch does not silently force-fit unexplained constants. The calculation model remains mathematically explicit and the discrepancy is recorded for confirmation.

### Video 3 — Tip Calculator
Observed sequence:
- Three fields: Bill Amount, Rate of Tip, Number of Person.
- Shared docked keypad with AC, delete, digits, decimal and equals.
- The reference result card has four separate values: Per Person Amount, Total Tip, Per Person Tip and Total Bill Amount.
- Sample 956 bill, 2% tip, 26 people yields 975.12 total, 19.12 total tip, 0.74 tip per person and 37.50 total per person (rounded to 2 decimals).

The previous implementation had only three displayed values and omitted the separate per-person-tip value. This patch adds that fourth output and aligns the labels/order with the recording.

## 2. Source corrections made
- Tip Calculator: added the missing Per Person Tip result and aligned the four displayed outputs to the reference sequence.
- SIP Delay Cost: added the missing “In today’s money value” result row; it discounts the future delay loss using an explicitly documented 6% annual inflation assumption.
- Mirrored `www/` HTML and JS assets are synchronized with canonical source assets.
- Added regression coverage for the exact Tip sample and the SIP present-value output.
- Existing shared keypad, loan validation, converter category flow and calculation code were preserved where the recordings did not demonstrate a defect.

## 3. Verification
- `npm test`: 60 tests passed, 0 failed.
- `npm run build:web`: completed; 13 required assets verified and canonical stylesheet copied.
- JavaScript syntax is exercised by the release test/build pipeline.
- Workflow YAML is preserved byte-for-byte from the supplied release workflow.

## 4. Scope and remaining verification
This is a source-level and recording-based review. No physical Android device was attached to this run, so touch latency, device-specific rendering, keyboard/inset behavior, battery impact and real-world lag cannot be certified here. The CI workflow can build the Android package, but a successful physical-device smoke test is still required before claiming device-level bug-free behavior.

The recordings directly demonstrate Loan, Unit Converter, SIP and Tip flows. They do not demonstrate every other tool screen; the existing full-tool regression suite remains the verification basis for those tools rather than an invented video-derived specification.
