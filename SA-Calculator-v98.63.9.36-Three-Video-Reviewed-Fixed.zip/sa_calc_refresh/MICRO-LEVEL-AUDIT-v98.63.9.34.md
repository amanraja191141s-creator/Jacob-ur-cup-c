# Micro-level audit — v98.63.9.34

## Evidence reviewed

- `Screenrecording_20261122_132803.mp4`
- `Screenrecording_20261122_132936.mp4`
- Prior source archive `SA-Calculator-v98.63.9.33-Tools-UI-Legacy-Removed-Fixed.zip`

## Confirmed video defects

1. Dark-theme Tools screens displayed a full-width bottom drawer while the numeric keys were compressed into a small grid at the lower-right, leaving a large empty panel.
2. Light-theme converter keypad used a substantially different key sizing/spacing treatment, so the shared control was not visually consistent across themes/tools.
3. Sales Tax and Loan result content was partly obscured by the dock in the captured flow.
4. Source CSS retained multiple historical popup keypad declarations and later overrides. The v98.63.9.33 final block constrained the dock to `max-width:560px` and capped keys with `17dvh`, while earlier declarations continued to participate in the cascade.
5. The JavaScript still used popup-era IDs/function names and a hard-coded `window.innerHeight * 0.51` active-field scroll boundary.

## Corrections applied

- Renamed the shared UI to `tool-keypad-dock`, `tool-keypad-grid`, `data-tool-key`, `openToolKeypad`, `closeToolKeypad` and `handleToolKey`.
- Removed legacy popup keypad CSS rules rather than hiding them under another override.
- One canonical dock rule now uses `100vw`, no max-width cap, a four-column/four-row grid and stretched key cells.
- Shared CSS height token controls both dock height and scroll padding.
- Active field positioning and result positioning now use the actual `getBoundingClientRect().top` of the dock.
- Result reveal filters hidden/inert cards and measures the lowest currently rendered result edge.
- Main calculator keypad and specialized HEX keypad remain separate.
- Workflow source selection prefers the exact repository checkout and avoids scanning unrelated archives when that checkout already matches. If an archive is needed, duplicate exact archives must have identical SHA-256 bytes.

## Verification

- `npm run build:web`: PASS
- `npm run test:release`: 55 passed, 0 failed
- JavaScript syntax checks: PASS
- PostCSS stylesheet parse: PASS
- Workflow YAML parse: PASS
- Root workflow and `.github/workflows/main.yml` mirror: byte-identical
- Source and generated `www` copies: byte-identical for HTML, JS and CSS
- ZIP integrity: to be verified at packaging

## Not claimed

The GitHub-hosted Gradle/APK build and physical Android device interaction test have not been executed in this environment. The workflow is hardened and statically tested, but remote Actions success is not asserted without a real run.
