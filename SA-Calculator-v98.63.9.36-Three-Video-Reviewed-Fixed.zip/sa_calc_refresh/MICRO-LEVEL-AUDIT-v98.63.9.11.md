# Micro-level audit — v98.63.9.11

## Source evidence
- Screenshot: requested expression/preview/result region occupies the red-marked upper portion; keypad begins below that boundary.
- Screen recording: currency/unit selector interaction exposes a long list of country/currency or unit names alongside the custom numeric keypad. This is noisy and obscures the active conversion input.

## Changes
1. Calculator display receives 46% of the active calculator viewport on standard portrait layouts.
2. Expression row, preview row, and committed-result mode remain inside that display region.
3. Five keypad rows use the remaining height; buttons scale within grid cells.
4. Compact-height and landscape breakpoints reduce display share to preserve usable keys.
5. Expression stays on one line and scrolls horizontally rather than wrapping.
6. Currency and unit pickers render the currently selected option only on open and while search is empty/one character.
7. Explicit searches require two characters and show at most eight matches.
8. `assets/` and `www/assets/` are synchronized for browser and Android WebView.

## Verification boundaries
Automated source/regression tests are run in CI/local Node. Physical Android rendering, device-specific font metrics, live provider availability, and APK installation require a device/build runner and are not certified by source tests alone.
