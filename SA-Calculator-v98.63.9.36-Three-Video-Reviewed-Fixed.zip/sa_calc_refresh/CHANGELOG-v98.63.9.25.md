# Changelog — v98.63.9.25

- Refined the scientific `＋` expansion interaction: the control changes to a clean `×` close state while the additional functions are visible, then restores `＋` when closed.
- Kept the expanded scientific panel on the same flat pink surface with unboxed text-only function keys; no extra headings, captions, cards, or duplicate keypad are introduced.
- Added Escape handling that closes the expanded function layer first, restores focus to the toggle, and leaves the current expression untouched. A second Escape closes the scientific drawer.
- Reset the expansion state and accessible label whenever the scientific drawer closes.
- Preserved scientific function tokens, INV one-shot behavior, angle mode, shared calculator expression, memory actions, and the existing Android build workflow.
- Bumped app release identity to `1.98.72-v98.63.9.25` and Android `versionCode` to `1098073` with a fresh service-worker cache namespace.
