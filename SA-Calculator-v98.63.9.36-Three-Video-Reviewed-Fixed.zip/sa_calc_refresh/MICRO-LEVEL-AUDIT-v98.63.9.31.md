# Micro-level audit — v98.63.9.31

## Scope
No private Cloudflare Worker or private API is shipped by this release.
App version: `1.98.78-v98.63.9.31`; Android versionCode: `1098079`.

Reference: `Screenrecording_20261122_105224.mp4` (88.1 seconds, 720×1560).
Target: the Tools input workflow shown in the recording, especially the on-demand numeric keypad.

## Reference behaviour extracted from the recording
- The Tools home is shown without a keyboard.
- Opening a tool does not automatically open the keyboard.
- The keyboard appears only after a numeric field is tapped.
- The form remains visible above the keyboard; it is not dimmed or covered by a modal backdrop.
- Tapping another field transfers the same keyboard to that field.
- The keypad uses four columns: `7 8 9 AC`, `4 5 6 Backspace`, `1 2 3 =`, and `00 0 decimal`; equals spans the final two rows.
- Pressing equals calculates and dismisses the keyboard; tapping a later field opens it again.
- Navigating away closes the keypad.

## Changes made
- Replaced the old modal/dim-overlay keypad presentation with a single docked, bottom-anchored keypad.
- Hid the redundant keypad title/preview panel; the selected form field remains the source of truth.
- Added a consistent four-column layout and tall equals key.
- Added active-field retargeting and scroll-into-view support for fields near the bottom of long forms.
- Kept native number-keyboard invocation suppressed for the custom-keypad fields.
- Added dismissal on tool navigation and Escape/system Back.
- Equals recalculates the current screen, persists inputs, and closes the keypad.
- Added Age Calculator, Salary and SIP to the Favorites registry.
- Kept the standard calculator's permanent keypad independent from the Tools keypad.

## Verification
- `node --check assets/js/app.js`: passed.
- `npm test` / release regression suite: 45 passed, 0 failed.
- `tests/release-gate.test.js`: 53 passed, 0 failed.
- `npm run build:web`: passed; canonical source files copied to `www/`.
- Root and generated `www/` HTML, CSS, JS, manifest and service-worker assets are synchronized.
- ZIP integrity check: passed.
- Workflow YAML parsing: passed.

## Remaining device-level validation
A real Android WebView / physical-device run is still required to certify OEM system-Back dispatch, soft-navigation bar insets, touch latency, and exact rendering across screen densities. CI can verify source and build readiness but cannot prove physical-device feel without the APK being installed and exercised.

## Follow-up action-time audit correction
A final GitHub Actions preflight review found a packaging defect not covered by the original keypad-only audit: the workflow listed `QA-RESULTS-v98.63.9.31.md` as mandatory, but that file was absent from the source archive. This deterministically failed the workflow's source-verification step before dependency installation and APK compilation. The missing report has been added. A new regression test, `tests/action-workflow-preflight-v9863931.test.mjs`, now parses the workflow's `required_files` list and verifies that every required file exists and is non-empty; it also checks the root and `.github/workflows/main.yml` copies are identical.

## Follow-up verification
- `npm test`: 47 passed, 0 failed.
- `node --test tests/release-gate.test.js`: 53 passed, 0 failed.
- `npm run build:web`: passed.
- Extracted final ZIP: `npm test` 47/47 and release gate 53/53 passed.
- Workflow YAML parsed successfully; workflow copies are byte-identical.
- Final ZIP integrity passed.

Physical Android APK execution and a GitHub-hosted Actions run remain external validations and are not claimed as completed.
