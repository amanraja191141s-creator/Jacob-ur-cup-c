# Release verification — v98.63.9.29

- Source identity: `1.98.76-v98.63.9.29`
- Android versionCode: `1098077`
- Main scientific function matrix: 4×4 preserved
- More function matrix: 4×4 preserved
- Key font scale: capped at 22 CSS px to match standard keypad typography
- Drawer top/height: live keypad rectangle variables
- INV: plain function label, one-shot inverse trig state
- More: compact circle within cell, accessible expanded state
- Root/WWW source copies: synchronized
- Test suite: 78 passing
- Web bundle: passing
- APK/device tests: pending
