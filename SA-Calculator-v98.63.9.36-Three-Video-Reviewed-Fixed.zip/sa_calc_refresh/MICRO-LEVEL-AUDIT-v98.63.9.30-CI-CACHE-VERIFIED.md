# SA Calculator v98.63.9.30 — CI Cache and Release Audit

## Scope
Audited the supplied `SA-Calculator-v98.63.9.30-CI-Cache-Fixed.zip` and the matching Android workflow. The release source remains `1.98.77-v98.63.9.30` with Android `versionCode` `1098078`.

## Verified
- Source ZIP integrity check passed; no corrupt ZIP entries.
- Exactly one app `package.json` was found in the supplied archive.
- All 37 workflow-required source files exist and are non-empty.
- JavaScript syntax checks passed for runtime, server, service worker, and Android preparation/patch scripts.
- `npm run build:web` passed and verified 13 required Android web assets.
- Release regression suite passed: **42 passed, 0 failed**.
- YAML parsed successfully and contains the expected `android-build` job.
- Source and generated service-worker cache namespaces match.
- Workflow source-selection logic requires the exact package version and rejects ambiguous exact-version archives.

## Changes made
- Added an explicit npm download cache using `actions/cache@v4`, keyed from OS, Node 22, and `**/package.json`.
- Kept `setup-node`'s built-in package-manager cache disabled because this source archive does not contain a `package-lock.json`; this avoids a lockfile lookup failure.
- Added `tests/ci-cache-workflow.test.mjs` and included it in `test:release`.
- Synchronized the current v98.63.9.30 workflow across `.github/workflows/main.yml` and the matching root workflow copies.
- Rebuilt the generated `www/` web bundle after source changes.

## Historical test-suite note
`npm run test:legacy` was also executed: **375 passed, 95 failed**. The failing tests include many pinned to older release identities and previous UI/workflow structures (for example v98.21–v98.63.9.29). They are not part of the current `test:release` gate. They were not silently rewritten to pass because doing so would replace historical assertions rather than validate this release. Some failures are behavior/UI expectation mismatches and should be reviewed individually if the legacy suite is intended to remain a supported gate.

## Not verified in this environment
- Android APK build and APK signing/identity: no Android SDK (`ANDROID_HOME` / `ANDROID_SDK_ROOT`) or Gradle installation is available in this runtime.
- A live GitHub Actions run: cannot be triggered from this local audit.

## Result
The web bundle and current release regression gate are verified. The Android workflow is prepared for CI, but an actual APK build must still run on GitHub Actions or an Android-SDK-equipped machine before claiming APK success.
